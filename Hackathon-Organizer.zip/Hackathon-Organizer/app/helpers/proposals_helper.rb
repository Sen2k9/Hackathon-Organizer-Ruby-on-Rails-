module ProposalsHelper
end
