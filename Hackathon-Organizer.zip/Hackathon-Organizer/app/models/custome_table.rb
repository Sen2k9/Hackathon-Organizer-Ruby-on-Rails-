class CustomeTable < ApplicationRecord
end
