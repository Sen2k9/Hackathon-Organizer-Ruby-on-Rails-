class Registration < ApplicationRecord
end
