# Milestone 1 - Instructions to the Instructors

- Team: Hackathon Organizer
- GitHub Repo URL: <https://github.com/memphis-cs-projects/comp7012-Hackathon-Organize>
- Demo Video URL: <https://youtu.be/vTYgG1R9umA>
- Git Tag for Demo Video Version of Code: milestone1 <https://github.com/memphis-cs-projects/comp7012-Hackathon-Organizer/releases/tag/milestone1>

## File Locations in Repository

- Milestone 1 Individual Assignment Outcomes: comp7012-Hackathon-Organizer/planning/Individual Assigments/
- Who-Did-What Document for Demo Video: /planning/whodidwhat
- Up-to-Date Requirements and Design Artifacts:
  - User stories: /planning/UserStories/
  - Sitemap: planning/WebMap
  - Class diagram of your model: planning/classDiagram
