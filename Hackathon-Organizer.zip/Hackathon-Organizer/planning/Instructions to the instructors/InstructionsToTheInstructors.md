# Milestone 0 - Instructions to the Instructors

- Team: Hackathon Organizer
- GitHub Repo URL: https://github.com/memphis-cs-projects/comp7012-Hackathon-Organizer

## File Locations in Repository

- User stories: planning/UserStories
- Sitemap: planning/WebMap
- User interface designs: planning/UI Sketeches/
- Class diagram of your model: planning/classDiagram
- Milestone 0 individual assignments and outcomes: planning/Individual Assignements/