# Glossary of Terms

**Team:** Hackathon Organizer

- Proposal
  - Theme for a hackathon to be selected
- Event
  - Refers to a hackathon itself.
