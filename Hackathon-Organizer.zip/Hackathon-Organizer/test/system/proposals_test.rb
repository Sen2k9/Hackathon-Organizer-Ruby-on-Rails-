require "application_system_test_case"

class ProposalsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit proposals_url
  #
  #   assert_selector "h1", text: "Proposal"
  # end
end
