require 'test_helper'

class HackathonTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
